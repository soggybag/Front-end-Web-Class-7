// Your data here
var data = [
    {
        title: "Hello World",
        desc: "Foo Bar",
        image: "images/image-1.jpg",
        bgColor: "#afa"
    }
];